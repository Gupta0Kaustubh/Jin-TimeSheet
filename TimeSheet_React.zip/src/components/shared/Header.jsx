import React from 'react'
import '../Styles/header.css'

export default function Header() {
  return (
    <div className='headername'>
        Teamsheet
    </div>
  )
}
